﻿using Core.Models;
using Snake.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;

namespace SnakeGame
{
    class Program
    {
        static string ProfileListPath = Directory.GetCurrentDirectory() + "\\Profiles\\Profiles.txt";

        static void Main(string[] args)
        {
            Console.WriteLine(Messages.IntroMessage);

            Console.WriteLine(Messages.Delimiter);
            Console.WriteLine();

            string profileName = Console.ReadLine();

            string profilesAvailable = File.ReadAllText(ProfileListPath);
            List<string> profileList = profilesAvailable.Split(Environment.NewLine).ToList();

            var foundProfile = false;
            foreach (var profile in profileList)
            {
                if (profile.Equals(profileName, StringComparison.InvariantCultureIgnoreCase))
                {
                    foundProfile = true;
                    break;
                }
            }

            var storedGamesPath = Directory.GetCurrentDirectory() + "\\Profiles\\" + profileName + "-storedgames.txt";
            List<string> storedStatesList = new List<string>();
            if (!foundProfile)
            {
                File.WriteAllLines(storedGamesPath, Enumerable.Empty<string>());
            }

            string storedStates = File.ReadAllText(storedGamesPath);
            if (foundProfile)
            {
                storedStatesList = storedStates.Split(Environment.NewLine).ToList();
                Console.WriteLine(Messages.SavedStates);
                foreach (var state in storedStatesList)
                {
                    Console.WriteLine(state);
                }

                Console.WriteLine(Messages.Delimiter);
                Console.WriteLine();

                Console.WriteLine(Messages.StoredStates);
            }
            else
            {
                profileList.Add(profileName);
                File.WriteAllLines(ProfileListPath, profileList);
                Console.WriteLine(Messages.NoStoredStates);
            }
            string profileState = Console.ReadLine();

            SnakeGameApp app;
            var profileStoredPath = Directory.GetCurrentDirectory() + "\\Profiles\\" + profileName + "-" + profileState + ".txt";
            if (File.Exists(profileStoredPath))
            {
                using (FileStream fs = new FileStream(profileStoredPath, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    app = (SnakeGameApp)bf.Deserialize(fs);
                }
            }
            else
            {
                Console.WriteLine(Messages.SppedSelector);
                var speedSelected = Console.ReadLine();
                GameSpeed speedType = GameSpeed.Slow;
                if (!Int32.TryParse(speedSelected, out int speed)
                    && speed > 0
                    && speed <= 4)
                {
                    Console.WriteLine(Messages.SppedSelectorError);
                    speed = 2;
                }

                switch (speed)
                {
                    case 1:
                        speedType = GameSpeed.VerySlow;
                        break;
                    case 2:
                        speedType = GameSpeed.Slow;
                        break;
                    case 3:
                        speedType = GameSpeed.Fast;
                        break;
                    case 4:
                        speedType = GameSpeed.VeryFast;
                        break;
                    default:
                        break;
                }

                app = new SnakeGameApp(speedType);
            }


            Console.Clear();

            var shouldSaveState = app.Run();

            if (shouldSaveState)
            {
                using (FileStream fs = new FileStream(profileStoredPath, FileMode.Create, FileAccess.Write))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, app);
                }

                var foundState = false;
                foreach (var profile in storedStatesList)
                {
                    if (profile.Equals(profileState, StringComparison.InvariantCultureIgnoreCase))
                    {
                        foundState = true;
                        break;
                    }
                }

                if (!foundState)
                {
                    storedStatesList.Add(profileState);
                    File.WriteAllLines(storedGamesPath, storedStatesList);
                }

            }

            if (System.Diagnostics.Debugger.IsAttached)
            {
                Console.WriteLine("\nPress <Enter> to continue...");
                Console.ReadLine();
            }
        }
    }



}