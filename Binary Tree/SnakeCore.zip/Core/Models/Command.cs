﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    [Serializable]
    public class Command
    {
        public Direction Heading { get; private set; }
        public char KeyPress { get; private set; }
        public char HeadToken { get; private set; }
        public int Degrees => (int)Heading;
        public Command Opposite => Board.DirectionMap.Get((Direction)(Degrees >= 180 ? Degrees - 180 : Degrees + 180));

        public bool IsUp
        {
            get
            {
                return Heading == Direction.Up;
            }
        }

        public bool IsRight => Heading == Direction.Right;
        public bool IsDown => Heading == Direction.Down;
        public bool IsLeft => Heading == Direction.Left;

        public Command(Direction vector, char keyPress, char headToken)
        {
            Heading = vector;
            KeyPress = keyPress;
            HeadToken = headToken;
        }

        public bool IsOpposite(Command dir)
        {
            return Math.Abs(Degrees - dir.Degrees) == 180;
        }

        public bool IsSame(Command dir)
        {
            return Heading == dir.Heading;
        }

        public string ToCommand()
        {
            return $"{KeyPress}: {Heading}";
        }
    }
}
