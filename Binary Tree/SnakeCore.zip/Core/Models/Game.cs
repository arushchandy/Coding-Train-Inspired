﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    [Serializable]
    public class Game
    {
        private readonly Direction initialHeading = Direction.Up;
        private DirectionMap directionMap = Board.DirectionMap;

        private Board board;
        public bool Lost { get; private set; } = false;
        public bool Quit { get; private set; } = false;

        public bool Pause { get; private set; } = false;

        public int SnakeLength { get; set; } = 5;

        public Game(GameSpeed speed)
        {
            board = new Board();
            var head = board.Center;
            board.Add(new Snake(head, initBody(head, SnakeLength - 1), directionMap.Get(initialHeading), speed));
            board.AddFood();
        }

        public void Draw()
        {
            board.Draw();
            Pause = false;
        }

        public void Play()
        {
            while (!Lost && !Quit && !Pause)
            {
                ConsoleKeyInfo input;
                if (Console.KeyAvailable)
                {
                    input = Console.ReadKey(true); //intercept = true (don't print char on console)
                    //If the directionMap doesn't find a direction for the character 
                    //the user pressed it throws an exception.
                    //Wrapping this in a try/catch allows us to ignore all non-direction keys
                    //except Escape, which quits the game.
                    try
                    {
                        var direction = directionMap.Get(input.KeyChar);
                        board.DoTurn(direction);
                        Lost = board.HasCollided;
                    }
                    catch
                    {
                        Quit = input.Key == ConsoleKey.Escape;
                        Pause = input.Key == ConsoleKey.End;
                    }
                }
                else
                {
                    board.DoTurn();
                    Lost = board.HasCollided;
                }
            }
        }

        private LinkedList<Pixels> initBody(Pixels head, int bodyLength)
        {
            var body = new LinkedList<Pixels>();
            var current = board.BottomNeighbor(head);
            for (var i = 0; i < bodyLength; i++)
            {
                body.AddLast(current);
                current.SetBody(bodyLength - i);
                current = board.BottomNeighbor(current);
            }
            return body;
        }
    }
}
