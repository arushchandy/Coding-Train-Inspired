﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Models
{
    [Serializable]
    public class Snake
    {
        public Pixels Head { get; private set; }
        public LinkedList<Pixels> Body { get; private set; }
        public Pixels Tail => Body.Last();
        public Command Direction { get; private set; }
        public int Length => BodyLength + 1;
        public int BodyLength => Body.Count; 
        public GameSpeed Speed { get; private set; }
        public bool HasEaten { get; private set; }

        public Snake(Pixels head, LinkedList<Pixels> body, Command initialHeading, GameSpeed speed)
        {
            Head = head;
            Body = body;
            Speed = speed;
            Direction = initialHeading;
            Head.SetHead(Direction.HeadToken);
        }

        public void Move(Command direction, Pixels nextHead)
        {
            var originalHead = Head;

            Direction = direction;

            HasEaten = false;

            if (nextHead.IsFood)
            {
                Eat();
            }

            Head = nextHead;

            Head.SetHead(direction.HeadToken);

            moveBody(originalHead);

            pause(); 
        }

        public void Eat()
        {
            HasEaten = true;
        }

        public void Grow(Pixels newTail)
        {
            newTail.SetBody(1);
            Body.AddLast(newTail);
        }

        private void moveBody(Pixels originalHead)
        {
            foreach (var cell in Body)
            {
                cell.Decay(); 
            }
            Body.AddFirst(originalHead);
            originalHead.SetBody(BodyLength - 1);
            Body.RemoveLast();
        }

        private void pause() => Thread.Sleep(((int)Speed));
    }
}
