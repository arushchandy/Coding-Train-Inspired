﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    [Serializable]
    public class DirectionMap
    {
        private Dictionary<char, Command> _directionKeys;
        private Dictionary<char, Command> directionKeys
        {
            get
            {
                _directionKeys = _directionKeys ?? directionKeyMap();
                return _directionKeys;
            }
        }

        private Dictionary<Direction, Command> _directionVectors;
        private Dictionary<Direction, Command> directionVectors
        {
            get
            {
                _directionVectors = _directionVectors ?? directionVectorMap();
                return _directionVectors;
            }
        }

        public Command Get(char c)
        {
            if (directionKeys.TryGetValue(c, out Command direction))
            {
                return direction;
            }
            else
            {
                throw new Exception($"{c} not found in direction map.");
            }
        }

        public Command Get(Direction vector)
        {
            if (directionVectors.TryGetValue(vector, out Command direction))
            {
                return direction;
            }
            else
            {
                throw new Exception($"Vector {vector.ToString()} not found in direction map.");
            }
        }

        public override string ToString() => string.Join(", ", directionVectors.Select(v => v.Value.ToCommand()));

        private Dictionary<Direction, Command> directionVectorMap()
        {
            return new Dictionary<Direction, Command>
            {
                {Direction.Left, new Command(Direction.Left , 'a', '<')},
                {Direction.Right, new Command(Direction.Right,'d', '>') },
                {Direction.Down, new Command(Direction.Down, 's', 'v') },
                {Direction.Up, new Command(Direction.Up, 'w', '^') }
            };
        }

        private Dictionary<char, Command> directionKeyMap() => directionVectors.ToDictionary(d => d.Value.KeyPress, d => d.Value);
    }
}
