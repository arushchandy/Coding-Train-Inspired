﻿public enum Direction
{
    Up = 0,
    Right = 90,
    Down = 180,
    Left = 270
}