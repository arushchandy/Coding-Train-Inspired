﻿using System;

namespace TicTacToe
{
    [Serializable]
    public class GameLogic
    {
        Board m_board;

        public GameLogic(Board board)
        {
            m_board = board == null ? throw new Exception("Board object is required.") : board;
        }

        public bool CheckForThree(char c)
        {
            return
                m_board.board[0, 0] == c && m_board.board[1, 0] == c && m_board.board[2, 0] == c
                ||
                m_board.board[0, 1] == c && m_board.board[1, 1] == c && m_board.board[2, 1] == c
                ||
                m_board.board[0, 2] == c && m_board.board[1, 2] == c && m_board.board[2, 2] == c
                ||
                m_board.board[0, 0] == c && m_board.board[0, 1] == c && m_board.board[0, 2] == c
                ||
                m_board.board[1, 0] == c && m_board.board[1, 1] == c && m_board.board[1, 2] == c
                ||
                m_board.board[2, 0] == c && m_board.board[2, 1] == c && m_board.board[2, 2] == c
                ||
                m_board.board[0, 0] == c && m_board.board[1, 1] == c && m_board.board[2, 2] == c
                ||
                m_board.board[2, 0] == c && m_board.board[1, 1] == c && m_board.board[0, 2] == c;

        }

        public bool CheckForFullBoard()
        {
            for (int i = 0; i < m_board.RowCount; i++)
            {
                for (int j = 0; j < m_board.ColumnCount; j++)
                {
                    if (m_board.board[i, j] == ' ')
                        return false;
                }
            }

            return true;
        }
    }
}
