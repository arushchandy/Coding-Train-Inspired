﻿public enum PlayMode
{
    None,

    Single,

    Multi
}

