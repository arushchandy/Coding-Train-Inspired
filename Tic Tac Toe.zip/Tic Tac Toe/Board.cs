﻿using System;

namespace TicTacToe
{
    [Serializable]
    public class Board
    {
        public char[,] board;

        public const int ROW_COUNT = 3;

        public const int COLUMN_COUNT = 3;

        public int RowCount
        {
            get
            {
                return ROW_COUNT;
            }
        }

        public int ColumnCount
        {
            get
            {
                return COLUMN_COUNT;
            }
        }

        public Board()
        {
            Initialize();
        }

        public void Initialize()
        {
            board = new char[ROW_COUNT, COLUMN_COUNT]
                  {
                    { ' ', ' ', ' ', },
                    { ' ', ' ', ' ', },
                    { ' ', ' ', ' ', },
                  };
        }

        public void DrawBoard()
        {
            Console.WriteLine();
            Console.WriteLine($" {board[0, 0]}  ||  {board[0, 1]}  ||  {board[0, 2]}");
            Console.WriteLine("    ||     ||");
            Console.WriteLine(" ===||=====||===");
            Console.WriteLine("    ||     ||");
            Console.WriteLine($" {board[1, 0]}  ||  {board[1, 1]}  ||  {board[1, 2]}");
            Console.WriteLine("    ||     ||");
            Console.WriteLine(" ===||=====||===");
            Console.WriteLine("    ||     ||");
            Console.WriteLine($" {board[2, 0]}  ||  {board[2, 1]}  ||  {board[2, 2]}");
        }
    }
}
