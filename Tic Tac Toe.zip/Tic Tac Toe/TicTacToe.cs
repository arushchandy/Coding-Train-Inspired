﻿using System;
using System.Collections.Generic;

namespace TicTacToe
{
    [Serializable]
    public class TicTacToe
    {
        bool closeRequested = false;
        public bool saveRequested = false;
        bool playerTurn = true;
        Board m_board;
        GameLogic m_logic;
        PlayMode m_mode;


        public TicTacToe(PlayMode mode)
        {
            // Initializes m_board.board array with empty characters.
            m_board = new Board();
            m_logic = new GameLogic(m_board);
            initialize();
            m_mode = mode;
        }

        private void initialize()
        {
            m_board.Initialize();
        }

        public bool Run()
        {
            // Render m_board.board characters on tictactoe m_board.board.
            m_board.DrawBoard();
            while (!closeRequested && !saveRequested)
            {
                while (!closeRequested && !saveRequested)
                {
                    if (playerTurn)
                    {
                        PlayerTurn(playerTurn);
                        if (m_logic.CheckForThree('X'))
                        {
                            FinishGame("You Win.");
                            break;
                        }
                    }
                    else
                    {
                        if (m_mode == PlayMode.Multi)
                        {
                            PlayerTurn(playerTurn);
                        }
                        else
                        {
                            AutomatedTurn();
                        }

                        if (m_logic.CheckForThree('O'))
                        {
                            FinishGame("You Lose.");
                            break;
                        }
                    }

                    playerTurn = !playerTurn;
                    if (m_logic.CheckForFullBoard())
                    {
                        FinishGame("Draw.");
                        break;
                    }
                }

                if (saveRequested)
                {
                    return true;
                }

                if (!closeRequested && !saveRequested)
                {
                    bool loopForAnswer = true;
                    while (loopForAnswer)
                    {
                        Console.WriteLine();
                        Console.WriteLine("\nWould you like to play again?\n\nTo play press[enter], to quit press[end]");

                        switch (Console.ReadKey(true).Key)
                        {
                            case ConsoleKey.Enter:
                                initialize();
                                loopForAnswer = false;
                                break;
                            case ConsoleKey.End:
                                closeRequested = true;
                                Console.Clear();
                                loopForAnswer = false;
                                break;
                            default:
                                loopForAnswer = true;
                                break;

                        }
                    }
                }
            }

            return false;
        }

        void PlayerTurn(bool isFirstPlayer)
        {
            int row = 0, column = 0;
            bool moved = false;
            while (!moved && !closeRequested && !saveRequested)
            {
                Console.Clear();
                m_board.DrawBoard();
                Console.WriteLine();

                if (m_board.board[row, column] is 'X' || m_board.board[row, column] is 'O')
                {
                    Console.WriteLine("This position is already used.... Use another position\n\n");
                }

                if (isFirstPlayer)
                {
                    Console.WriteLine("X's Turn \n\n");
                }
                else
                {
                    Console.WriteLine("Y's Turn \n\n");
                }

                Console.WriteLine("Choose a valid position and press enter. \n");
                Console.WriteLine("**To quit press [end] key \n**To save press [escape] key ");
                Console.SetCursorPosition(column * 6 + 1, row * 4 + 1);
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.UpArrow: row = row <= 0 ? 2 : row - 1; break;
                    case ConsoleKey.DownArrow: row = row >= 2 ? 0 : row + 1; break;
                    case ConsoleKey.LeftArrow: column = column <= 0 ? 2 : column - 1; break;
                    case ConsoleKey.RightArrow: column = column >= 2 ? 0 : column + 1; break;
                    case ConsoleKey.Enter:
                        if (m_board.board[row, column] is ' ')
                        {
                            m_board.board[row, column] = isFirstPlayer ? 'X' : 'O';
                            moved = true;
                        }
                        break;
                    case ConsoleKey.End:
                        Console.Clear();
                        closeRequested = true;
                        break;
                    case ConsoleKey.Escape:
                        Console.Clear();
                        saveRequested = true;
                        break;
                }
            }
        }

        void AutomatedTurn()
        {
            Random random = new Random();
            var possibleMoves = new List<(int X, int Y)>();
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (m_board.board[i, j] == ' ')
                    {
                        possibleMoves.Add((i, j));
                    }
                }
            }
            int index = random.Next(0, possibleMoves.Count);
            var (X, Y) = possibleMoves[index];
            m_board.board[X, Y] = 'O';
        }

        void FinishGame(string message)
        {
            Console.Clear();
            m_board.DrawBoard();
            Console.WriteLine();
            message = (playerTurn ? " X " : "O" ) + " , " + message;
            Console.Write(message);
        }
    }
}
