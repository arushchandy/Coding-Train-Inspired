﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace TicTacToe
{
    public class Program
    {
        public const string IntroMessage = "Hello, welcome to the game. Please enter your profile name.";

        public const string Delimiter = "--------------------------------------------------------------------------------";

        public static void Main(string[] args)
        {
            //Start Intro information

            Console.WriteLine(IntroMessage);
            Console.WriteLine(Delimiter);
            Console.WriteLine();
            Console.WriteLine();

            //End Intro information

            // Reads user profile name, till only aphabtes are given
            string profileName = "";
            bool validName = false;
            do
            {
                profileName = Console.ReadLine();
                profileName = profileName.ToLower();
                if (profileName.Length >= 5)
                {
                    Regex r = new Regex("^[a-zA-Z]+$");

                    if (r.IsMatch(profileName))
                        validName = true;
                    else
                        validName = false;
                }

                if (!validName)
                {
                    Console.WriteLine("Only alphabets with minimum character length of 5 or more are allowed as profile name.");
                }

            } while (!validName);

            // End Reads user profile name, till only aphabtes are given


            // Check if user has any saved games.
            TicTacToe app = null;
            var savedGamePath = Directory.GetCurrentDirectory() + "\\Profiles\\" + profileName + "-savedgame.txt";
            if (File.Exists(savedGamePath))
            {
                Console.WriteLine("");
                Console.WriteLine("You have already saved games, do you wish to continue. ");
                Console.WriteLine("Enter Y to continue, or enter otherwise to start new.");

                string userOption = Console.ReadLine();
                if (userOption.ToLower().Equals("y"))
                {
                    using (FileStream fs = new FileStream(savedGamePath, FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter bf = new BinaryFormatter();
                        app = (TicTacToe)bf.Deserialize(fs);
                        app.saveRequested = false;
                    }
                }
                else
                {
                    File.Delete(savedGamePath);
                }
            }

            // If no saved state exits or new game.
            if (app == null)
            {
                app = new TicTacToe();
            }

            // Clear console.
            Console.Clear();

            var shouldSaveState = app.Run();
            if (shouldSaveState)
            {
                using (FileStream fs = new FileStream(savedGamePath, FileMode.Create, FileAccess.Write))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, app);
                }
                Console.WriteLine("State saved.");
            }


            Console.WriteLine("\nPress <Enter> to continue...");
            Console.ReadLine();
        }

    }

}